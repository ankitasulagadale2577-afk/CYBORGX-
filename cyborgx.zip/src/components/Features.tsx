import React, { useRef, useState } from "react";
import { motion, useMotionValue, useSpring, useTransform } from "motion/react";
import { BrainCircuit, Eye, Zap, HeartPulse, Cpu, Fingerprint } from "lucide-react";
import { FeatureUnit } from "../types";

// Array of 6 Features
const FEATURES: FeatureUnit[] = [
  {
    id: "neural-interface",
    title: "Neural Interface",
    description: "Connect your consciousness directly to our global AI neural network. Synchronize memory buffers and streamline data streams in real time.",
    iconName: "brain",
    glowColor: "rgba(6, 182, 212, 0.4)", // Cyan
    borderColor: "border-cyan-500/20 group-hover:border-cyan-400/50",
    badge: "RECOMMENDED",
  },
  {
    id: "ai-vision",
    title: "AI Vision",
    description: "Equip your sensory organs with contextual real-time data overlays. Augmented HUD interfaces, spectrum shifting, and instant thermal mapping.",
    iconName: "eye",
    glowColor: "rgba(16, 185, 129, 0.4)", // Emerald
    borderColor: "border-emerald-500/20 group-hover:border-emerald-400/50",
    badge: "POPULAR",
  },
  {
    id: "cyber-limbs",
    title: "Cybernetic Limbs",
    description: "Durable mechanical prosthetic architecture built with titanium alloys. Achieve outstanding physical capability and ergonomic force outputs.",
    iconName: "cyber-limb",
    glowColor: "rgba(168, 85, 247, 0.4)", // Purple
    borderColor: "border-purple-500/20 group-hover:border-purple-400/50",
    badge: "TACTICAL",
  },
  {
    id: "smart-health",
    title: "Health Monitoring",
    description: "Real-time bio-metric telemetry connected to diagnostic chips. Automatically regulates insulin levels, monitors blood pressures, and predicts vulnerabilities.",
    iconName: "health",
    glowColor: "rgba(244, 63, 94, 0.4)", // Rose
    borderColor: "border-rose-500/20 group-hover:border-rose-400/50",
    badge: "PREMIUM",
  },
  {
    id: "quantum-processing",
    title: "Quantum Processing",
    description: "Deploy embedded co-processors directly into your cybernetic spine. Resolve dense algorithms and secure cloud decryption locally.",
    iconName: "quantum",
    glowColor: "rgba(59, 130, 246, 0.4)", // Blue
    borderColor: "border-blue-500/20 group-hover:border-blue-400/50",
    badge: "CORE",
  },
  {
    id: "secure-auth",
    title: "Secure Bio Auth",
    description: "Multilayer credentials locked to custom DNA sequences. Impervious to standard cyber threats or remote neural hijackers.",
    iconName: "fingerprint",
    glowColor: "rgba(236, 72, 153, 0.4)", // Pink
    borderColor: "border-pink-500/20 group-hover:border-pink-400/50",
    badge: "MIL-SPEC",
  },
];

// Feature Card with 3D Interactive Mouse Tilt
function FeatureCard({ feature }: { feature: FeatureUnit }) {
  const cardRef = useRef<HTMLDivElement | null>(null);
  const [hovered, setHovered] = useState(false);

  // Motion values to track cursor position inside the card coordinate plane
  const x = useMotionValue(0);
  const y = useMotionValue(0);

  // Smooth springs for a tactile feeling of resistance
  const rotateX = useSpring(useTransform(y, [-0.5, 0.5], [10, -10]), { damping: 20, stiffness: 200 });
  const rotateY = useSpring(useTransform(x, [-0.5, 0.5], [-10, 10]), { damping: 20, stiffness: 200 });

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!cardRef.current) return;
    const rect = cardRef.current.getBoundingClientRect();
    const width = rect.width;
    const height = rect.height;

    // Normalize coordinates to ranges from -0.5 to 0.5 (where center is 0, 0)
    const relativeX = (e.clientX - rect.left) / width - 0.5;
    const relativeY = (e.clientY - rect.top) / height - 0.5;

    x.set(relativeX);
    y.set(relativeY);
  };

  const handleMouseLeave = () => {
    setHovered(false);
    x.set(0);
    y.set(0);
  };

  const renderIcon = (name: string) => {
    const iconClass = "w-7 h-7 transition-transform duration-500 group-hover:scale-110";
    switch (name) {
      case "brain":
        return <BrainCircuit className={`${iconClass} text-cyan-400`} />;
      case "eye":
        return <Eye className={`${iconClass} text-emerald-400`} />;
      case "cyber-limb":
        return <Zap className={`${iconClass} text-purple-400`} />;
      case "health":
        return <HeartPulse className={`${iconClass} text-rose-400`} />;
      case "quantum":
        return <Cpu className={`${iconClass} text-blue-400`} />;
      case "fingerprint":
        return <Fingerprint className={`${iconClass} text-pink-400`} />;
      default:
        return <BrainCircuit className={`${iconClass} text-cyan-400`} />;
    }
  };

  return (
    <motion.div
      ref={cardRef}
      onMouseMove={handleMouseMove}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={handleMouseLeave}
      style={{
        transformStyle: "preserve-3d",
        rotateX: rotateX,
        rotateY: rotateY,
      }}
      className="h-full"
    >
      <div
        className={`relative h-full p-6 sm:p-8 bg-zinc-950/45 border rounded-lg backdrop-blur-md transition-all duration-300 group overflow-hidden ${feature.borderColor}`}
        style={{
          boxShadow: hovered ? `0 10px 40px -10px ${feature.glowColor}` : "none",
        }}
      >
        {/* Glow backdrop behind icon with mouse location sync */}
        <div
          className="absolute -top-12 -left-12 w-24 h-24 rounded-full blur-[40px] opacity-15 group-hover:opacity-30 group-hover:scale-150 transition-all duration-500"
          style={{ backgroundColor: feature.glowColor }}
        />

        {/* Micro-Indicator Bio-Badge */}
        <div className="flex justify-between items-start mb-6">
          <div className="p-3 bg-zinc-900 border border-zinc-800 rounded-lg group-hover:shadow-[0_0_15px_rgba(255,255,255,0.05)] duration-300">
            {renderIcon(feature.iconName)}
          </div>
          <span className="text-[9px] font-mono tracking-widest text-zinc-500 bg-zinc-900/80 border border-zinc-800/60 px-2 py-0.5 rounded leading-none">
            {feature.badge}
          </span>
        </div>

        {/* Card Copywriting */}
        <h3 className="text-lg sm:text-xl font-display font-medium text-white mb-3 group-hover:text-cyan-400 transition-colors duration-200">
          {feature.title}
        </h3>
        <p className="text-zinc-400 text-xs sm:text-sm leading-relaxed">
          {feature.description}
        </p>

        {/* Futuristic bottom line graphic */}
        <div className="absolute bottom-0 inset-x-0 h-[2px] bg-gradient-to-r from-transparent via-cyan-500/0 to-transparent group-hover:via-cyan-500/50 transition-all duration-500" />
      </div>
    </motion.div>
  );
}

export default function Features() {
  return (
    <section
      id="features"
      className="py-24 sm:py-32 relative text-center overflow-hidden border-t border-zinc-950"
    >
      {/* Background vector visual flares */}
      <div className="absolute top-1/2 left-0 w-80 h-80 bg-pink-500/5 rounded-full blur-[100px] pointer-events-none" />
      <div className="absolute bottom-0 right-0 w-80 h-80 bg-cyan-500/5 rounded-full blur-[100px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16 sm:mb-24">
          <div className="inline-block px-3 py-1 bg-purple-950/40 border border-purple-500/30 rounded-full font-mono text-[10px] tracking-widest text-purple-400 mb-4 uppercase">
            AUGMENTATION FEATURES
          </div>
          <h2 className="text-3xl sm:text-5xl font-display font-bold tracking-tight text-white mb-6 uppercase">
            ENGINEERED TO REMOVE YOUR{" "}
            <span className="bg-gradient-to-r from-cyan-400 to-indigo-400 bg-clip-text text-transparent">
              LIMITS.
            </span>
          </h2>
          <p className="text-neutral-400 text-sm sm:text-base leading-relaxed">
            Every cybernetic module we implement undergoes continuous machine-learning simulations to
            ensure high synergy coefficients with biological tissue. Explore the core capabilities.
          </p>
        </div>

        {/* Card Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
          {FEATURES.map((feature, idx) => (
            <motion.div
              key={feature.id}
              initial={{ opacity: 0, y: 35 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-100px" }}
              transition={{ delay: idx * 0.08, duration: 0.6 }}
            >
              <FeatureCard feature={feature} />
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
