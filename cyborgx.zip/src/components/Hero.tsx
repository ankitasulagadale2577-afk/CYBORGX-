import { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Play, ArrowDown, Sparkles, Binary, RefreshCw, Cpu, Activity } from "lucide-react";

export default function Hero() {
  const [demoOpen, setDemoOpen] = useState(false);
  const [hudStats, setHudStats] = useState({
    synapticCharge: 88.5,
    neuralSync: 99.98,
    quantumClock: "4.82 GHz",
    status: "STABLE",
  });

  const handleScrollDown = () => {
    const el = document.querySelector("#technology");
    if (el) el.scrollIntoView({ behavior: "smooth" });
  };

  const calibrateSystems = () => {
    // Generate simulated telemetry fluctuation
    setHudStats({
      synapticCharge: parseFloat((85 + Math.random() * 14).toFixed(2)),
      neuralSync: parseFloat((99.9 + Math.random() * 0.09).toFixed(2)),
      quantumClock: `${(4.5 + Math.random() * 0.9).toFixed(2)} GHz`,
      status: "CALIBRATING",
    });
    setTimeout(() => {
      setHudStats((prev) => ({ ...prev, status: "STABLE" }));
    }, 1200);
  };

  return (
    <section
      id="hero"
      className="min-h-screen relative flex items-center justify-center pt-24 pb-16 overflow-hidden"
    >
      {/* Background neon light flares */}
      <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-cyan-500/10 rounded-full blur-[120px] pointer-events-none animate-pulse-slow" />
      <div className="absolute bottom-1/4 right-1/4 w-[500px] h-[500px] bg-purple-500/10 rounded-full blur-[140px] pointer-events-none animate-pulse-slow" />

      {/* Futuristic City Backdrop (Unsplash overlay mapped to dark tone) */}
      <div
        className="absolute inset-0 bg-cover bg-center -z-30 opacity-[0.07] mix-blend-color-dodge transition-all duration-1000"
        style={{
          backgroundImage: `url('https://images.unsplash.com/photo-1542838132-92c53300491e?auto=format&fit=crop&w=1600&q=80')`,
        }}
      />

      {/* Cyber Grid Base Texture */}
      <div className="absolute inset-0 bg-radial-at-c from-transparent via-black/40 to-black/95 -z-10 pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full relative grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
        {/* Left: Branding, Copy Content */}
        <div className="lg:col-span-7 flex flex-col items-start text-left relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="inline-flex items-center gap-2 px-3 py-1 bg-cyan-950/40 border border-cyan-500/30 rounded-full mb-6 font-mono text-[10px] sm:text-xs tracking-widest text-cyan-400"
          >
            <Sparkles className="w-3.5 h-3.5 animate-spin duration-1000" />
            HUMAN AUGMENTATION v4.08
          </motion.div>

          <motion.h1
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.1 }}
            className="text-4xl sm:text-6xl lg:text-7xl font-display font-black tracking-tighter leading-[1.05] text-white mb-6 uppercase"
          >
            The Future is <br />
            <span className="bg-gradient-to-r from-cyan-400 via-indigo-200 to-pink-500 bg-clip-text text-transparent drop-shadow-[0_0_15px_rgba(6,182,212,0.3)]">
              No Longer Human.
            </span>
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.2 }}
            className="text-base sm:text-lg text-neutral-400 max-w-xl font-normal leading-relaxed mb-10"
          >
            Experience next-generation human augmentation powered by artificial
            intelligence, cybernetics, and neural technology. Overcome biological
            limits and access quantum logic interfaces.
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.3 }}
            className="flex flex-wrap items-center gap-4 sm:gap-6 w-full"
          >
            {/* Get Started Button */}
            <a
              href="#products"
              onClick={(e) => {
                e.preventDefault();
                document.querySelector("#products")?.scrollIntoView({ behavior: "smooth" });
              }}
              className="px-8 py-4 bg-cyan-500 text-black font-display text-xs font-bold tracking-widest rounded transition-all hover:bg-cyan-400 hover:shadow-[0_0_25px_#06b6d4] duration-300 uppercase relative group"
            >
              Get Started
            </a>

            {/* Watch Demo Button */}
            <button
              onClick={() => setDemoOpen(true)}
              className="px-8 py-4 bg-zinc-950 hover:bg-zinc-900 border border-zinc-700/60 rounded text-cyan-400 font-display text-xs font-bold tracking-widest hover:border-cyan-400 transition-all duration-300 flex items-center gap-3 uppercase cursor-pointer"
            >
              <div className="w-5 h-5 rounded-full bg-cyan-500/10 flex items-center justify-center border border-cyan-500/30">
                <Play className="w-2.5 h-2.5 fill-cyan-400 text-cyan-400 ml-0.5" />
              </div>
              Watch Demo
            </button>
          </motion.div>

          {/* Quick HUD telemetry highlights */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.5, duration: 1 }}
            className="mt-12 pt-8 border-t border-zinc-900 grid grid-cols-2 sm:grid-cols-3 gap-6 w-full max-w-lg font-mono text-[11px]"
          >
            <div>
              <div className="text-zinc-500 uppercase tracking-widest mb-1">LATENCY STATE</div>
              <div className="text-white font-bold tracking-wider">0.02ms PROT-O</div>
            </div>
            <div>
              <div className="text-zinc-500 uppercase tracking-widest mb-1">CORTICAL SYNC</div>
              <div className="text-emerald-400 font-bold tracking-wider">99.98% OPTIMAL</div>
            </div>
            <div className="hidden sm:block">
              <div className="text-zinc-500 uppercase tracking-widest mb-1">DATA PROCESSING</div>
              <div className="text-cyan-400 font-bold tracking-wider">50M+ COMP/SEC</div>
            </div>
          </motion.div>
        </div>

        {/* Right: Immersive Interactive Bionic HUD Visual */}
        <div className="lg:col-span-5 h-[400px] sm:h-[500px] relative w-full flex items-center justify-center">
          <motion.div
            initial={{ opacity: 0, scale: 0.85 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 1, delay: 0.2 }}
            className="relative w-full max-w-[420px] h-full flex items-center justify-center animate-float-slow"
          >
            {/* Outer Concentric Rotating Ring */}
            <div className="absolute inset-0 border border-solid border-cyan-500/10 rounded-full aspect-square flex items-center justify-center">
              <div className="absolute inset-2 border-2 border-dashed border-cyan-500/20 rounded-full animate-spin [animation-duration:45s]" />
              <div className="absolute inset-6 border border-dotted border-purple-500/30 rounded-full animate-spin [animation-duration:20s]" />
              <div className="absolute inset-16 border border-zinc-800 rounded-full" />
            </div>

            {/* Simulated Robotic Core Matrix (Holographic SVG Graphic) */}
            <svg
              viewBox="0 0 200 200"
              className="absolute w-72 h-72 z-10 drop-shadow-[0_0_20px_rgba(6,182,212,0.4)]"
            >
              {/* Outer tech circular notches */}
              <circle
                cx="100"
                cy="100"
                r="85"
                fill="none"
                stroke="cyan"
                strokeWidth="0.75"
                strokeDasharray="6 4 12 6"
                className="opacity-70"
              />
              {/* Spinning middle brackets */}
              <circle
                cx="100"
                cy="100"
                r="70"
                fill="none"
                stroke="#6366f1"
                strokeWidth="1.5"
                strokeDasharray="40 100"
                className="origin-center animate-spin"
                style={{ animationDuration: "12s" }}
              />
              <circle
                cx="100"
                cy="100"
                r="64"
                fill="none"
                stroke="#a855f7"
                strokeWidth="1.2"
                strokeDasharray="20 40 10 20"
                className="origin-center animate-spin"
                style={{ animationDuration: "8s", animationDirection: "reverse" }}
              />

              {/* Glowing vector wires representing neural pathways */}
              <g className="opacity-90">
                <path d="M 100 100 L 40 40" stroke="cyan" strokeWidth="0.75" strokeDasharray="3 3" />
                <path d="M 100 100 L 160 40" stroke="indigo" strokeWidth="0.75" />
                <path d="M 100 100 L 50 140" stroke="#ec4899" strokeWidth="0.75" />
                <path d="M 100 100 L 150 145" stroke="cyan" strokeWidth="0.75" strokeDasharray="5 2" />

                {/* Nodes */}
                <circle cx="40" cy="40" r="3" fill="cyan" />
                <circle cx="160" cy="40" r="3" fill="#6366f1" />
                <circle cx="50" cy="140" r="3" fill="#ec4899" />
                <circle cx="150" cy="145" r="3" fill="cyan" />
              </g>

              {/* Pulsating core */}
              <defs>
                <radialGradient id="techCore" cx="50%" cy="50%" r="50%">
                  <stop offset="0%" stopColor="#22d3ee" stopOpacity="0.8" />
                  <stop offset="40%" stopColor="#0891b2" stopOpacity="0.5" />
                  <stop offset="100%" stopColor="#0f172a" stopOpacity="0" />
                </radialGradient>
              </defs>
              <circle cx="100" cy="100" r="28" fill="url(#techCore)" className="animate-pulse" />
              <circle cx="100" cy="100" r="4" fill="white" />
            </svg>

            {/* Overlay cyber floating data panels (Glassmorphism look) */}
            <div className="absolute top-4 -right-2 bg-black/80 border border-cyan-500/30 px-3.5 py-2.5 rounded shadow-[0_0_15px_rgba(6,182,212,0.15)] backdrop-blur-md text-[10px] sm:text-xs text-left font-mono z-25 min-w-[150px]">
              <div className="flex items-center gap-1.5 text-cyan-400 font-bold mb-1.5 uppercase">
                <Activity className="w-3.5 h-3.5 animate-pulse text-pink-500" />
                COGNITIVE DIAGS
              </div>
              <div className="space-y-1 text-zinc-300">
                <div className="flex justify-between">
                  <span>SYNAPTIC COMP:</span>
                  <span className="text-cyan-300 font-bold">{hudStats.synapticCharge}%</span>
                </div>
                <div className="flex justify-between">
                  <span>NEURAL INTEGRATION:</span>
                  <span className="text-emerald-400 font-bold">{hudStats.neuralSync}%</span>
                </div>
                <div className="flex justify-between">
                  <span>FREQUENCY CORE:</span>
                  <span className="text-zinc-100">{hudStats.quantumClock}</span>
                </div>
              </div>
            </div>

            {/* Floating button to trigger live calibration */}
            <button
              onClick={calibrateSystems}
              className="absolute -bottom-2 -left-2 bg-black/80 hover:bg-neutral-900 border border-purple-500/40 hover:border-purple-400 px-4 py-2 rounded-full cursor-pointer shadow-[0_0_15px_rgba(168,85,247,0.1)] backdrop-blur-md text-[10px] font-mono font-bold tracking-widest text-purple-300 flex items-center gap-2 z-25 group"
            >
              <RefreshCw
                className={`w-3.5 h-3.5 text-purple-400 ${
                  hudStats.status === "CALIBRATING" ? "animate-spin" : "group-hover:rotate-180"
                } transition-transform duration-500`}
              />
              SYSTEM: {hudStats.status}
            </button>

            {/* Scanning light sweeping beam */}
            <div className="absolute top-0 inset-x-8 h-0.5 bg-gradient-to-r from-transparent via-cyan-500 to-transparent shadow-[0_0_12px_#06b6d4] animate-scanline pointer-events-none" />
          </motion.div>
        </div>
      </div>

      {/* Futuristic Scroll Indicator */}
      <div className="absolute bottom-6 left-1/2 transform -translate-x-1/2 flex flex-col items-center gap-2 z-10">
        <span className="text-[10px] font-mono tracking-[0.3em] uppercase text-zinc-500">
          DISCOVER TECHNOLOGY
        </span>
        <button
          onClick={handleScrollDown}
          className="w-6 h-10 border border-zinc-700/80 rounded-full flex justify-center p-1 group hover:border-cyan-400 duration-300 cursor-pointer"
        >
          <motion.div
            animate={{
              y: [0, 12, 0],
            }}
            transition={{
              duration: 1.5,
              repeat: Infinity,
              ease: "easeInOut",
            }}
            className="w-1.5 h-2 bg-cyan-400 rounded-full"
          />
        </button>
      </div>

      {/* Cinematic Telemetry Watch Demo Video Overlay Modal */}
      <AnimatePresence>
        {demoOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-100 flex items-center justify-center p-4 bg-black/90 backdrop-blur-md"
          >
            <motion.div
              initial={{ scale: 0.9, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.9, y: 20 }}
              className="bg-zinc-950 border border-cyan-500/20 rounded-lg p-6 max-w-4xl w-full relative overflow-hidden shadow-[0_0_50px_rgba(6,182,212,0.15)] font-mono text-xs text-cyan-300"
            >
              {/* Holographic matrix grids */}
              <div className="absolute inset-0 bg-scanlines pointer-events-none opacity-[0.03]" />

              {/* Modal header */}
              <div className="flex justify-between items-center pb-4 border-b border-cyan-950/40 mb-6">
                <div className="flex items-center gap-2 font-display font-medium tracking-wider text-white">
                  <Binary className="w-5 h-5 text-cyan-400 animate-pulse" />
                  CYBORGX // DEMO FEED: ACTIVE
                </div>
                <button
                  onClick={() => setDemoOpen(false)}
                  className="px-3 py-1 cursor-pointer bg-zinc-900 border border-zinc-800 text-neutral-400 hover:text-white hover:border-cyan-500 rounded text-[10px]"
                >
                  TERMINATE FEED
                </button>
              </div>

              {/* Interactive Virtual HUD Console Feed */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {/* Tech specifications column */}
                <div className="md:col-span-1 space-y-4 border-r border-cyan-950/30 pr-4">
                  <div className="bg-zinc-900/60 p-3 rounded border border-zinc-800">
                    <div className="text-zinc-500 mb-1.5">AUGMENT INTEGRATION:</div>
                    <div className="text-lg font-bold text-white tracking-widest font-display">
                      SUCCESS
                    </div>
                  </div>
                  <div className="bg-zinc-900/60 p-3 rounded border border-zinc-800">
                    <div className="text-zinc-500 mb-1.5">NEURAL CORE ADAPTER:</div>
                    <div className="text-white text-sm font-semibold">COGNIO-v9 ENHANCED</div>
                  </div>
                  <div className="p-3 bg-cyan-950/10 border border-cyan-500/10 rounded">
                    <div className="text-cyan-400 mb-2 font-semibold">AUTONOMOUS FEED STATUS</div>
                    <div className="flex items-center gap-1.5 text-emerald-400 text-[10px]">
                      <span className="w-1.5 h-1.5 bg-emerald-400 rounded-full animate-ping" />
                      COGNITIVE BRIDGE OPERATIONAL
                    </div>
                  </div>
                </div>

                {/* Simulated Visual Video Area / Visual Calibration HUD */}
                <div className="md:col-span-2 aspect-video bg-black rounded border border-cyan-950/60 flex flex-col justify-between p-4 relative overflow-hidden">
                  {/* Digital crosshair targeting vector */}
                  <div className="absolute inset-0 flex items-center justify-center pointer-events-none opacity-40">
                    <div className="w-24 h-24 border border-dashed border-cyan-600 rounded-full animate-spin" style={{ animationDuration: '30s' }} />
                    <div className="absolute w-40 h-40 border-2 border-indigo-500/10 rounded-full" />
                    <div className="absolute w-1 h-12 bg-pink-500/60" />
                    <div className="absolute h-1 w-12 bg-pink-500/60" />
                  </div>

                  <div className="flex justify-between items-start">
                    <div className="text-[10px] text-zinc-500">LOC: 35.6762° N, 139.6503° E (TOKYO INTEGRATIVE LAB)</div>
                    <div className="px-1.5 py-0.5 bg-red-500/15 border border-red-500/35 text-red-500 font-bold tracking-widest animate-pulse h-fit rounded-[2px] text-[9px]">
                      LIVE FEED
                    </div>
                  </div>

                  <div className="text-center my-auto py-10 scale-95 flex flex-col items-center">
                    <Cpu className="w-12 h-12 text-cyan-400 animate-bounce mb-3" />
                    <p className="font-display font-medium text-lg text-white mb-2 uppercase">
                      AUGMENT CALIBRATION IN PROGRESS
                    </p>
                    <p className="text-[11px] text-zinc-400 max-w-sm">
                      Streaming secure quantum packets directly to visual cortex. Sync rate is operating at 99.9% target efficiency.
                    </p>
                  </div>

                  <div className="flex justify-between text-[10px] text-zinc-500 font-mono">
                    <span>INDEX-6112-SYS</span>
                    <span>FRAME RATE: 120 FPS // CLOUD COGNITION SECURE</span>
                  </div>
                </div>
              </div>

              {/* Lower HUD text ticker */}
              <div className="mt-6 pt-4 border-t border-cyan-950/40 text-[10px] text-zinc-500 uppercase flex justify-between">
                <span>ENHANCED BY CYBORGX AI LABS</span>
                <span>DATA SECURED VIA 256-BIT NEURAL CRYPTO</span>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </section>
  );
}
