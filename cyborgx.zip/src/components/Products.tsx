import { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { ShoppingCart, ShieldAlert, BadgeInfo, Star, Check } from "lucide-react";
import { ProductItem } from "../types";

// List of 3 premium bionic products
const PRODUCTS: ProductItem[] = [
  {
    id: "neural-x-implant",
    name: "Neural-X Implant",
    tagline: "Cerebral Neural Gateway",
    price: "$4,999",
    description: "Our flagship bio-chip implant. Restructures synaptic pathways to enable zero-latency cognitive operations and secure network connections.",
    features: [
      "Zero-Latency Cognitive Sync",
      "Dynamic Synapse Structuring",
      "128-Bit End-to-End Neural Crypto",
      "Embedded Quantum Co-Processor",
    ],
    imageUrl: "neural",
    specs: [
      { label: "Sync Coefficients", value: "99.98% Synapse Match" },
      { label: "Data Bandwidth", value: "50 Gbps Direct Link" },
      { label: "Power Supply", value: "Inductive Kinetic Charger" },
      { label: "Material", value: "Bio-Inert Titanium-Glass" },
    ],
  },
  {
    id: "vision-x-lens",
    name: "Vision-X Lens",
    tagline: "Augmented Retinal HUD",
    price: "$1,850",
    description: "Sleek contact overlays built with premium graphene polymers. Displays live telemetry, thermal shifts, and visual spectrum modification filters.",
    features: [
      "High-Contrast HUD Overlays",
      "Infrared & Thermal Shifting",
      "Dynamic Autofocus Magnification",
      "Anti-Glair UV Wave Filters",
    ],
    imageUrl: "lens",
    specs: [
      { label: "Display Density", value: "32,000 ppi Micro-LED" },
      { label: "Response Speeds", value: "0.01ms Local Frame" },
      { label: "Battery Cells", value: "Micro-kinetic Solar Array" },
      { label: "Ductility", value: "98.5% Oxygen Permeability" },
    ],
  },
  {
    id: "cyber-arm-pro",
    name: "Cyber Arm Pro",
    tagline: "Biomechatronic Extremity",
    price: "$12,400",
    description: "Next-gen titanium physical replacement. Integrates embedded muscle-fiber sensors that match motor cortex decisions instantly.",
    features: [
      "Titanium-Carbon Fiber Weave",
      "Integrated Tactile Haptic Array",
      "Adaptive Gripping Torque Controls",
      "Embedded Tools Interface",
    ],
    imageUrl: "arm",
    specs: [
      { label: "Max Compression", value: "3,200 Newtons Torque" },
      { label: "Total Mass", value: "3.4 kg Neutral Weight" },
      { label: "Joint Mobility", value: "360-degree Radial Axis" },
      { label: "Coupler Link", value: "Direct Neuro-Bone Coupler" },
    ],
  },
];

export default function Products() {
  const [selectedProduct, setSelectedProduct] = useState<ProductItem | null>(null);
  const [cartCount, setCartCount] = useState(0);
  const [addedProduct, setAddedProduct] = useState<string | null>(null);

  const handleOrder = (productName: string) => {
    setCartCount((c) => c + 1);
    setAddedProduct(productName);
    setTimeout(() => {
      setAddedProduct(null);
    }, 2000);
  };

  const renderProductGraphic = (type: string) => {
    switch (type) {
      case "neural":
        return (
          <svg viewBox="0 0 120 120" className="w-24 h-24 text-cyan-400 drop-shadow-[0_0_8px_#06b6d4]">
            {/* Neural chip blueprint */}
            <rect x="35" y="35" width="50" height="50" rx="6" fill="none" stroke="currentColor" strokeWidth="1.5" />
            <circle cx="60" cy="60" r="14" fill="none" stroke="currentColor" strokeWidth="1" strokeDasharray="3 3 shrink" />
            {/* Pin lines */}
            <line x1="25" y1="45" x2="35" y2="45" stroke="currentColor" strokeWidth="1" />
            <line x1="25" y1="60" x2="35" y2="60" stroke="currentColor" strokeWidth="1" />
            <line x1="25" y1="75" x2="35" y2="75" stroke="currentColor" strokeWidth="1" />
            <line x1="85" y1="45" x2="95" y2="45" stroke="currentColor" strokeWidth="1" />
            <line x1="85" y1="60" x2="95" y2="60" stroke="currentColor" strokeWidth="1" />
            <line x1="85" y1="75" x2="95" y2="75" stroke="currentColor" strokeWidth="1" />

            <line x1="45" y1="25" x2="45" y2="35" stroke="currentColor" strokeWidth="1" />
            <line x1="60" y1="25" x2="60" y2="35" stroke="currentColor" strokeWidth="1" />
            <line x1="75" y1="25" x2="75" y2="35" stroke="currentColor" strokeWidth="1" />
            <line x1="45" y1="85" x2="45" y2="95" stroke="currentColor" strokeWidth="1" />
            <line x1="60" y1="85" x2="60" y2="95" stroke="currentColor" strokeWidth="1" />
            <line x1="75" y1="85" x2="75" y2="95" stroke="currentColor" strokeWidth="1" />

            {/* Glowing nodes */}
            <circle cx="60" cy="60" r="4" fill="#a855f7" className="animate-pulse" />
          </svg>
        );
      case "lens":
        return (
          <svg viewBox="0 0 120 120" className="w-24 h-24 text-emerald-400 drop-shadow-[0_0_8px_#10b981]">
            {/* Double lenses */}
            <circle cx="60" cy="60" r="42" fill="none" stroke="currentColor" strokeWidth="1.5" />
            <circle cx="60" cy="60" r="28" fill="none" stroke="currentColor" strokeWidth="0.75" strokeDasharray="6 3" />
            <circle cx="60" cy="60" r="16" fill="none" stroke="currentColor" strokeWidth="1" />

            {/* HUD reticle markers */}
            <line x1="10" y1="60" x2="18" y2="60" stroke="currentColor" strokeWidth="1.5" />
            <line x1="102" y1="60" x2="110" y2="60" stroke="currentColor" strokeWidth="1.5" />
            <line x1="60" y1="10" x2="60" y2="18" stroke="currentColor" strokeWidth="1.5" />
            <line x1="60" y1="102" x2="60" y2="110" stroke="currentColor" strokeWidth="1.5" />

            {/* Scanning sector */}
            <path d="M 60 60 L 98 42 A 42 42 0 0 0 85 20 Z" fill="rgba(16, 185, 129, 0.1)" stroke="none" />
          </svg>
        );
      case "arm":
        return (
          <svg viewBox="0 0 120 120" className="w-24 h-24 text-purple-400 drop-shadow-[0_0_8px_#a855f7]">
            {/* Custom cybernetic arm vector skeleton */}
            <path d="M 15 60 L 40 55 L 75 62 L 95 55 L 110 60" fill="none" stroke="currentColor" strokeWidth="2" />
            {/* Joint Gears */}
            <circle cx="40" cy="55" r="8" fill="none" stroke="currentColor" strokeWidth="1.5" />
            <circle cx="75" cy="62" r="6" fill="none" stroke="currentColor" strokeWidth="1.5" />
            {/* Hydraulic pistons */}
            <line x1="25" y1="75" x2="55" y2="72" stroke="currentColor" strokeWidth="0.75" />
            <line x1="40" y1="55" x2="75" y2="62" stroke="currentColor" strokeWidth="0.5" strokeDasharray="3 3" />
            <circle cx="40" cy="55" r="3" fill="#ec4899" className="animate-pulse" />
          </svg>
        );
      default:
        return null;
    }
  };

  return (
    <section id="products" className="py-24 sm:py-32 relative border-t border-zinc-950">
      {/* Glow effects */}
      <div className="absolute top-1/2 left-1/3 w-96 h-96 bg-cyan-600/5 rounded-full blur-[120px] pointer-events-none" />
      <div className="absolute top-[80%] right-0 w-[500px] h-[500px] bg-indigo-600/5 rounded-full blur-[140px] pointer-events-none" />

      {/* Cart Status Indicator inside section header */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-end mb-16 sm:mb-24 gap-6">
          <div>
            <div className="inline-block px-3 py-1 bg-pink-950/40 border border-pink-500/30 rounded-full font-mono text-[10px] tracking-widest text-pink-400 mb-4 uppercase">
              BIONIC PRODUCTS
            </div>
            <h2 className="text-3xl sm:text-5xl font-display font-bold tracking-tight text-white uppercase">
              REDEFINE YOUR <br />
              <span className="bg-gradient-to-r from-cyan-400 via-purple-300 to-pink-500 bg-clip-text text-transparent">
                CAPABILITY.
              </span>
            </h2>
          </div>

          {/* Secure Shop Registry Indicator */}
          <div className="flex items-center gap-4 bg-zinc-950/80 border border-zinc-900 rounded-lg p-3 backdrop-blur-md">
            <div className="w-10 h-10 rounded bg-cyan-950/30 border border-cyan-500/20 flex items-center justify-center relative">
              <ShoppingCart className="w-5 h-5 text-cyan-400" />
              {cartCount > 0 && (
                <span className="absolute -top-1.5 -right-1.5 w-5 h-5 rounded-full bg-pink-500 text-black text-[10px] font-bold flex items-center justify-center">
                  {cartCount}
                </span>
              )}
            </div>
            <div className="text-left font-mono">
              <div className="text-[10px] text-zinc-500">BIOLINK REGISTRY</div>
              <div className="text-xs text-white font-bold">{cartCount} UNITS ALLOCATED</div>
            </div>
          </div>
        </div>

        {/* Outer Product Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {PRODUCTS.map((prod, idx) => (
            <motion.div
              key={prod.id}
              initial={{ opacity: 0, scale: 0.95, y: 30 }}
              whileInView={{ opacity: 1, scale: 1, y: 0 }}
              viewport={{ once: true, margin: "-80px" }}
              transition={{ delay: idx * 0.1, duration: 0.5 }}
              className="bg-zinc-950/40 border border-zinc-900 hover:border-cyan-500/30 rounded-xl overflow-hidden backdrop-blur-md transition-all duration-300 group flex flex-col h-full relative"
            >
              {/* Product Vector Image Schematic Area */}
              <div className="aspect-[4/3] bg-zinc-950/80 border-b border-zinc-900/80 flex items-center justify-center relative overflow-hidden group-hover:bg-black/40 duration-300">
                {/* Tech scan grid pattern */}
                <div className="absolute inset-0 bg-scanlines opacity-[0.02]" />
                <div className="absolute text-[9px] font-mono text-zinc-700 top-3 left-4 select-none">
                  SCHEMATIC // MODEL_v9
                </div>

                {/* Animated vector graphics */}
                <motion.div
                  whileHover={{ scale: 1.1, rotate: 5 }}
                  transition={{ type: "spring", stiffness: 150, damping: 15 }}
                >
                  {renderProductGraphic(prod.imageUrl)}
                </motion.div>
              </div>

              {/* Product Text Copywriting info */}
              <div className="p-6 sm:p-8 flex-1 flex flex-col justify-between">
                <div>
                  <div className="text-[10px] font-mono tracking-widest text-zinc-500 mb-1 uppercase">
                    {prod.tagline}
                  </div>
                  <h3 className="text-xl sm:text-2xl font-display font-semibold text-white mb-2 group-hover:text-cyan-400 transition-colors">
                    {prod.name}
                  </h3>
                  <div className="text-cyan-400 font-mono text-base font-bold mb-4">{prod.price}</div>
                  <p className="text-zinc-400 text-xs sm:text-sm leading-relaxed mb-6">
                    {prod.description}
                  </p>

                  <ul className="space-y-2 mb-8 text-xs text-neutral-300 font-mono">
                    {prod.features.slice(0, 3).map((f) => (
                      <li key={f} className="flex items-center gap-2">
                        <Check className="w-3.5 h-3.5 text-emerald-400 flex-shrink-0" />
                        <span>{f}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Card CTA Actions */}
                <div className="flex gap-4">
                  <button
                    onClick={() => setSelectedProduct(prod)}
                    className="flex-1 py-3 bg-zinc-900 hover:bg-zinc-850 border border-zinc-800 hover:border-cyan-500/50 rounded font-display text-[11px] font-bold tracking-widest text-white transition-all duration-300 uppercase flex items-center justify-center gap-2 cursor-pointer"
                  >
                    <BadgeInfo className="w-4 h-4 text-cyan-400" />
                    Specs
                  </button>
                  <button
                    onClick={() => handleOrder(prod.name)}
                    className="flex-1 py-3 rounded font-display text-[11px] font-bold tracking-widest bg-gradient-to-r from-cyan-500 to-indigo-500 text-black duration-300 uppercase hover:shadow-[0_0_15px_rgba(6,182,212,0.5)] cursor-pointer"
                  >
                    {addedProduct === prod.name ? "Syncing..." : "Acquire"}
                  </button>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>

      {/* Specifications Details Modal */}
      <AnimatePresence>
        {selectedProduct && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-100 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md"
          >
            <motion.div
              initial={{ scale: 0.95, y: 15 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.95, y: 15 }}
              className="bg-zinc-950 border border-zinc-800 rounded-lg p-6 sm:p-8 max-w-lg w-full relative overflow-hidden shadow-[0_0_40px_rgba(0,0,0,0.8)]"
            >
              {/* Technical background decorations */}
              <div className="absolute top-0 right-0 w-32 h-32 bg-cyan-500/5 rounded-full blur-[30px]" />

              <h3 className="text-xl sm:text-2xl font-display font-medium text-white mb-1">
                {selectedProduct.name}
              </h3>
              <div className="text-cyan-400 font-mono text-xs mb-6 uppercase tracking-wider">
                {selectedProduct.tagline} • Detailed Specs
              </div>

              {/* Technical list schema table */}
              <div className="space-y-4 mb-8">
                <div className="text-zinc-500 font-mono text-[10px] uppercase tracking-widest border-b border-zinc-800 pb-1.5">
                  SYSTEM TELEMETRY
                </div>
                <div className="grid grid-cols-1 gap-3">
                  {selectedProduct.specs.map((item) => (
                    <div
                      key={item.label}
                      className="flex justify-between items-center py-2 border-b border-zinc-900/60 font-mono text-xs"
                    >
                      <span className="text-zinc-500">{item.label}</span>
                      <span className="text-white font-bold">{item.value}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Security Advisory */}
              <div className="p-3.5 bg-red-950/15 border border-red-500/20 rounded flex items-start gap-3 mb-8">
                <ShieldAlert className="w-5 h-5 text-red-500 flex-shrink-0 mt-0.5" />
                <div className="text-left">
                  <div className="text-[11px] text-red-400 font-bold uppercase tracking-wider">
                    SECURE DEPLOYMENT ADVISORY
                  </div>
                  <div className="text-[10px] text-zinc-400 leading-normal mt-1">
                    Installation requires safe general anesthesia at certified CYBORGX containment hubs.
                    Ensure biological firmware compatibility prior to ordering.
                  </div>
                </div>
              </div>

              {/* Close Button */}
              <button
                onClick={() => setSelectedProduct(null)}
                className="w-full py-3 bg-zinc-900 hover:bg-zinc-850 text-center font-display text-[11px] font-bold tracking-widest text-cyan-400 hover:text-cyan-300 rounded border border-zinc-800 uppercase duration-200 cursor-pointer"
              >
                Close Spec Sheet
              </button>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </section>
  );
}
