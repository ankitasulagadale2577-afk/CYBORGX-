import { useState, FormEvent, MouseEvent } from "react";
import { Cpu, Github, Twitter, Layers, ArrowUp, Send, Check } from "lucide-react";

export default function Footer() {
  const [email, setEmail] = useState("");
  const [success, setSuccess] = useState(false);

  const handleSubscribe = (e: FormEvent) => {
    e.preventDefault();
    if (!email) return;
    setSuccess(true);
    setEmail("");
    setTimeout(() => {
      setSuccess(false);
    }, 4000);
  };

  const scrollToTop = (e: MouseEvent) => {
    e.preventDefault();
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  return (
    <footer id="footer" className="bg-black border-t border-zinc-900 pt-20 pb-10 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Upper Footer section */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-12 pb-16 border-b border-zinc-900/60">
          
          {/* Logo & Company Bio */}
          <div className="md:col-span-5 space-y-6">
            <a
              href="#hero"
              onClick={scrollToTop}
              className="flex items-center gap-2 font-display text-white tracking-widest font-black text-xl hover:opacity-90 duration-200 uppercase"
            >
              <div className="w-8 h-8 rounded bg-cyan-950/40 border border-cyan-500/20 flex items-center justify-center p-1 text-cyan-400">
                <Cpu className="w-5 h-5" />
              </div>
              <span>
                CYBORG<span className="text-cyan-400">X</span>
              </span>
            </a>

            <p className="text-zinc-500 text-xs sm:text-sm leading-relaxed max-w-sm">
              CYBORGX develops human augmentation and cybernetic interfaces. Empowering unbiassed intelligence scaling and physical enhancements globally.
            </p>

            {/* Social icons */}
            <div className="flex gap-4 items-center pt-2">
              <a
                href="https://github.com"
                target="_blank"
                rel="noopener noreferrer"
                className="w-9 h-9 border border-zinc-900 hover:border-cyan-500/30 rounded bg-zinc-950 flex items-center justify-center text-zinc-500 hover:text-cyan-400 transition-colors duration-200"
                aria-label="CYBORGX GitHub Repository"
              >
                <Github className="w-4 h-4" />
              </a>
              <a
                href="https://twitter.com"
                target="_blank"
                rel="noopener noreferrer"
                className="w-9 h-9 border border-zinc-900 hover:border-cyan-500/30 rounded bg-zinc-950 flex items-center justify-center text-zinc-500 hover:text-cyan-400 transition-colors duration-200"
                aria-label="CYBORGX X Profile"
              >
                <Twitter className="w-4 h-4" />
              </a>
              <a
                href="https://discord.com"
                target="_blank"
                rel="noopener noreferrer"
                className="w-9 h-9 border border-zinc-900 hover:border-cyan-500/30 rounded bg-zinc-950 flex items-center justify-center text-zinc-500 hover:text-cyan-400 transition-colors duration-200"
                aria-label="CYBORGX Discord Server"
              >
                <Layers className="w-4 h-4" />
              </a>
            </div>
          </div>

          {/* Quick links columns */}
          <div className="md:col-span-3 grid grid-cols-2 gap-6 md:gap-4">
            <div className="space-y-4">
              <h4 className="font-mono text-xs font-bold tracking-widest text-white uppercase">
                AUGMENTATIONS
              </h4>
              <ul className="space-y-2.5 text-xs text-neutral-500 font-mono">
                <li>
                  <a href="#products" className="hover:text-cyan-400 duration-200">
                    Neural Gateway
                  </a>
                </li>
                <li>
                  <a href="#products" className="hover:text-cyan-400 duration-200">
                    Ocular Retinals
                  </a>
                </li>
                <li>
                  <a href="#products" className="hover:text-cyan-400 duration-200">
                    Cyber Extremities
                  </a>
                </li>
                <li>
                  <a href="#features" className="hover:text-cyan-400 duration-200">
                    Diagnostics
                  </a>
                </li>
              </ul>
            </div>

            <div className="space-y-4">
              <h4 className="font-mono text-xs font-bold tracking-widest text-white uppercase">
                CYBORGX
              </h4>
              <ul className="space-y-2.5 text-xs text-neutral-500 font-mono">
                <li>
                  <a href="#about" className="hover:text-cyan-400 duration-200">
                    Manifesto
                  </a>
                </li>
                <li>
                  <a href="#theme" className="hover:text-cyan-400 duration-200">
                    Research Lab
                  </a>
                </li>
                <li>
                  <a href="#testimonials" className="hover:text-cyan-400 duration-200">
                    Tester Logs
                  </a>
                </li>
                <li>
                  <a href="#hero" className="hover:text-cyan-400 duration-200">
                    Legal Policy
                  </a>
                </li>
              </ul>
            </div>
          </div>

          {/* Newsletter Input */}
          <div className="md:col-span-4 space-y-4">
            <h4 className="font-mono text-xs font-bold tracking-widest text-white uppercase">
              SUBSCRIBE TO CYBERSTREAMS
            </h4>
            <p className="text-zinc-500 text-xs leading-relaxed font-mono">
              Retrieve periodic firmware updates, bionic product alerts, and neural system diagnostics.
            </p>

            <form onSubmit={handleSubscribe} className="flex gap-2 w-full pt-1">
              <input
                type="email"
                placeholder="SECURE_EMAIL_PROT_0"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="flex-1 bg-zinc-950 border border-zinc-900 rounded p-3 text-xs text-cyan-300 font-mono focus:outline-none focus:border-cyan-500 duration-200 placeholder-zinc-700"
                required
              />
              <button
                type="submit"
                className="px-4 bg-cyan-500 text-black rounded flex items-center justify-center hover:bg-cyan-400 duration-200 cursor-pointer"
                aria-label="Subscribe Newsletter"
              >
                {success ? <Check className="w-4 h-4 text-emerald-950" /> : <Send className="w-4 h-4" />}
              </button>
            </form>
            {success && (
              <p className="font-mono text-[10px] text-emerald-400 animate-pulse">
                Secure stream logged. Calibration alerts initialized.
              </p>
            )}
          </div>

        </div>

        {/* Lower footer section details */}
        <div className="mt-10 flex flex-col sm:flex-row justify-between items-center gap-6 text-[11px] text-zinc-500 font-mono">
          <div className="text-center sm:text-left select-none">
            © {new Date().getFullYear()} CYBORGX BIOLINK INC // SECURE LICENSING UNDER CORTICAL CODE v4.2
          </div>
          
          {/* Scroll to Top Trigger */}
          <a
            href="#hero"
            onClick={scrollToTop}
            className="flex items-center gap-2 group hover:text-cyan-400 duration-250 uppercase cursor-pointer"
          >
            GRID BACK_PLANE TOP
            <div className="w-7 h-7 border border-zinc-900 rounded bg-zinc-950 group-hover:border-cyan-500/40 flex items-center justify-center text-zinc-600 group-hover:text-cyan-400 duration-250">
              <ArrowUp className="w-3.5 h-3.5 group-hover:-translate-y-0.5 duration-200" />
            </div>
          </a>
        </div>

      </div>
    </footer>
  );
}
