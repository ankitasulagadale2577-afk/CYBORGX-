import { useEffect, useState } from "react";
import { motion, AnimatePresence } from "motion/react";

interface LoadingScreenProps {
  onComplete: () => void;
}

const BOOT_LOGS = [
  "CONNECTING SUB-CEREBRAL LINK...",
  "ESTABLISHING QUANTUM LINKAGE [PORT: 9200]...",
  "SECURE BIO-METRIC DECRYPT: ACTIVE...",
  "CALIBRATING OPTICAL AI ENHANCERS...",
  "SYNAPSE TRANSMISSION: MATCHED AT 99.98%...",
  "CYBORG COGNITION BOOT: COMPLETE.",
];

export default function LoadingScreen({ onComplete }: LoadingScreenProps) {
  const [progress, setProgress] = useState(0);
  const [logIndex, setLogIndex] = useState(0);
  const [logs, setLogs] = useState<string[]>([BOOT_LOGS[0]]);
  const [isFinishing, setIsFinishing] = useState(false);

  useEffect(() => {
    // Fast bootloader sequence
    const interval = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval);
          setTimeout(() => {
            setIsFinishing(true);
            setTimeout(() => {
              onComplete();
            }, 800);
          }, 400);
          return 100;
        }
        const step = Math.floor(Math.random() * 8) + 4;
        return Math.min(prev + step, 100);
      });
    }, 85);

    return () => clearInterval(interval);
  }, [onComplete]);

  // Handle stream logs showing one after another as progress goes up
  useEffect(() => {
    const nextLogTrigger = Math.floor((100 / BOOT_LOGS.length) * (logIndex + 1));
    if (progress >= nextLogTrigger && logIndex < BOOT_LOGS.length - 1) {
      setLogIndex((i) => i + 1);
      setLogs((prev) => [...prev, BOOT_LOGS[logIndex + 1]]);
    }
  }, [progress, logIndex]);

  return (
    <AnimatePresence>
      {!isFinishing && (
        <motion.div
          id="cyber-loading-overlay"
          initial={{ opacity: 1 }}
          exit={{ opacity: 0, scale: 1.05 }}
          transition={{ duration: 0.6, ease: "easeInOut" }}
          className="fixed inset-0 z-100 flex flex-col items-center justify-center bg-black select-none text-cyan-400 font-mono p-4"
        >
          {/* Subtle Cyber Grid Grid Background */}
          <div className="absolute inset-0 bg-[linear-gradient(rgba(18,24,38,0.1)_1px,transparent_1px),linear-gradient(90deg,rgba(18,24,38,0.1)_1px,transparent_1px)] bg-[size:30px_30px] opacity-40 pointer-events-none" />

          {/* Scanning sweep line */}
          <div className="absolute top-0 left-0 w-full h-1 bg-cyan-500/20 shadow-[0_0_15px_#06b6d4] animate-scanline pointer-events-none" />

          <div className="w-full max-w-lg relative px-6 py-8 border border-cyan-950/40 bg-zinc-950/80 rounded-lg backdrop-blur-md shadow-[0_0_50px_rgba(6,182,212,0.05)]">
            {/* Header */}
            <div className="flex justify-between items-center mb-8 border-b border-cyan-950/50 pb-4">
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 bg-cyan-500 animate-pulse rounded-full" />
                <span className="text-sm font-bold tracking-widest text-cyan-200">
                  SYSTEM INITIALIZATION: CYBORGX
                </span>
              </div>
              <span className="text-xs text-neutral-500">v4.88-AI</span>
            </div>

            {/* Circular HUD Loader Graphic */}
            <div className="flex justify-center mb-8 relative">
              <div className="relative w-32 h-32 flex items-center justify-center">
                {/* SVG Spinning Rings */}
                <svg className="absolute w-full h-full transform -rotate-90">
                  <circle
                    cx="64"
                    cy="64"
                    r="52"
                    stroke="rgba(8, 51, 68, 0.4)"
                    strokeWidth="3"
                    fill="transparent"
                  />
                  <motion.circle
                    cx="64"
                    cy="64"
                    r="52"
                    stroke="#06b6d4"
                    strokeWidth="3.5"
                    fill="transparent"
                    strokeDasharray={2 * Math.PI * 52}
                    strokeDashoffset={2 * Math.PI * 52 * (1 - progress / 100)}
                    className="shadow-[0_0_15px_rgba(6,182,212,0.8)]"
                  />
                </svg>

                {/* Additional Rotating Ring */}
                <span className="absolute w-24 h-24 rounded-full border border-dashed border-purple-500/60 animate-spin" />

                {/* Counter text */}
                <div className="text-center">
                  <div className="text-2xl font-bold font-display tracking-wider text-white">
                    {progress}%
                  </div>
                  <div className="text-[10px] text-cyan-500 tracking-widest">
                    SYNCING
                  </div>
                </div>
              </div>
            </div>

            {/* Logging Streams */}
            <div className="h-32 bg-black/70 rounded border border-cyan-950/40 p-3 overflow-hidden text-[11px] leading-relaxed flex flex-col justify-end">
              <div className="space-y-1.5 font-mono text-cyan-300">
                {logs.map((log, i) => (
                  <div key={i} className="flex">
                    <span className="text-neutral-500 mr-2">&gt;</span>
                    <span>{log}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Footer Calibration Indicators */}
            <div className="mt-6 flex justify-between text-[10px] text-neutral-500">
              <div className="flex gap-4">
                <span>SECURE-BOOT: TRUE</span>
                <span>DEVICES: DETECTED (3)</span>
              </div>
              <span>STABLE // 0.02ms</span>
            </div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
