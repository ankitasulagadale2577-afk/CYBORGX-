import { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Sliders, Shield, Zap, RefreshCw, Layers, Sparkles } from "lucide-react";
import { TechnologyStep } from "../types";

// 4 Transformation timeline steps
const TIMELINE_STEPS: TechnologyStep[] = [
  {
    phase: "PHASE 01: COGNITIVE ZERO",
    title: "Biological Baseline",
    year: "Year 0 // Clean Slate",
    description: "Standard unenhanced biological tissue, subject to biochemical degradation, physical limitations, and chemical signaling delays.",
    stats: [
      { label: "Neural Accuracy", value: "62.4%" },
      { label: "Response Time", value: "220ms" },
      { label: "Decisions / Sec", value: "240" },
      { label: "Health Optimization", value: "45%" },
    ],
    enhancementLevel: 10,
  },
  {
    phase: "PHASE 02: NEURAL TRIGGER",
    title: "Cortical Linkage",
    year: "Year 1 // Synapse Sync",
    description: "Implementation of first-generation bio-chip into the occipital lobe. Interlinks sensory registers with high-speed quantum databases.",
    stats: [
      { label: "Neural Accuracy", value: "85.2%" },
      { label: "Response Time", value: "18ms" },
      { label: "Decisions / Sec", value: "1.2M" },
      { label: "Health Optimization", value: "72%" },
    ],
    enhancementLevel: 45,
  },
  {
    phase: "PHASE 03: SENSORY DEPLOY",
    title: "Optical HUD & Sensory Hub",
    year: "Year 2 // Spectrum HUD",
    description: "Deployment of custom bionic lenses and auditory filter gates, displaying algorithmic HUD trackers directly onto the cornea.",
    stats: [
      { label: "Neural Accuracy", value: "95.8%" },
      { label: "Response Time", value: "2.5ms" },
      { label: "Decisions / Sec", value: "18M" },
      { label: "Health Optimization", value: "88%" },
    ],
    enhancementLevel: 75,
  },
  {
    phase: "PHASE 04: APEX SYNTHESIS",
    title: "Apex Cyborg Organism",
    year: "Year 3 // Cyber Sovereign",
    description: "Ultimate biological and machine merger. Embedded carbon-nanotube motor fibers, localized quantum co-processors, and full bio-authentication.",
    stats: [
      { label: "Neural Accuracy", value: "99.9%" },
      { label: "Response Time", value: "0.02ms" },
      { label: "Decisions / Sec", value: "50M+" },
      { label: "Health Optimization", value: "98%" },
    ],
    enhancementLevel: 100,
  },
];

export default function Showcase() {
  const [activeStep, setActiveStep] = useState(0);

  const step = TIMELINE_STEPS[activeStep];

  return (
    <section
      id="technology"
      className="py-24 sm:py-32 relative border-t border-cyan-950/20 bg-slate-950/30"
    >
      {/* Background vector visual halos */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-[600px] h-[600px] bg-indigo-500/5 rounded-full blur-[140px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Section Title */}
        <div className="text-center max-w-3xl mx-auto mb-16 sm:mb-24">
          <div className="inline-block px-3 py-1 bg-cyan-950/40 border border-cyan-500/30 rounded-full font-mono text-[10px] tracking-widest text-cyan-400 mb-4 uppercase">
            TECHNOLOGY SHOWCASE
          </div>
          <h2 className="text-3xl sm:text-5xl font-display font-bold tracking-tight text-white mb-6 uppercase">
            HUMAN → CYBORG <br />
            <span className="bg-gradient-to-r from-cyan-400 via-indigo-200 to-purple-500 bg-clip-text text-transparent">
              TRANSFORMATION.
            </span>
          </h2>
          <p className="text-neutral-400 text-sm sm:text-base leading-relaxed">
            Drag the interface slider or select phases below to witness the incremental biophysical adjustments
            applied by our advanced neural surgeries.
          </p>
        </div>

        {/* Dashboard Grid Container */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          {/* Left Panel: Holographic Wireframe Visual Simulation */}
          <div className="lg:col-span-5 flex flex-col items-center">
            <div className="relative w-full max-w-[380px] aspect-[4/5] bg-zinc-950/60 border border-cyan-500/20 rounded-xl p-6 flex flex-col justify-between overflow-hidden shadow-[0_0_35px_rgba(6,182,212,0.04)] backdrop-blur-md">
              {/* Subtle digital scanning layout indicators */}
              <div className="absolute inset-x-0 top-0 h-0.5 bg-gradient-to-r from-transparent via-cyan-500/30 to-transparent shadow-[0_0_10px_rgba(6,182,212,0.3)] animate-scanline" />

              {/* Holographic Header */}
              <div className="flex justify-between items-center font-mono text-[10px] text-zinc-500">
                <span className="flex items-center gap-1.5 font-bold text-cyan-400">
                  <span className="w-1.5 h-1.5 bg-cyan-400 rounded-full animate-ping" />
                  VISUALIZATION ENGINE
                </span>
                <span>SEC-922</span>
              </div>

              {/* SVG Hologram representing the biomechanical status */}
              <div className="relative my-6 flex-1 flex justify-center items-center">
                <svg
                  viewBox="0 0 160 220"
                  className="w-full max-h-[250px] transition-transform duration-500 hover:scale-105"
                >
                  {/* Subtle Grid Base inside visualizer */}
                  <g opacity="0.15">
                    <line x1="0" y1="110" x2="160" y2="110" stroke="#06b6d4" strokeWidth="0.5" />
                    <line x1="80" y1="0" x2="80" y2="220" stroke="#06b6d4" strokeWidth="0.5" />
                    <circle cx="80" cy="110" r="50" fill="none" stroke="#06b6d4" strokeWidth="0.5" />
                    <circle cx="80" cy="110" r="90" fill="none" stroke="#06b6d4" strokeWidth="0.5" />
                  </g>

                  {/* Body wireframe (Abstract sleek medical humanoid outline) */}
                  <path
                    d="M 80 35 C 74 35, 74 47, 80 47 Z"
                    fill="none"
                    stroke={activeStep >= 2 ? "#06b6d4" : "#374151"}
                    strokeWidth="1.5"
                    className="transition-colors duration-500"
                  />
                  <path
                    d="M 80 47 L 80 110 M 80 60 L 50 78-45 120 M 80 60 L 110 78-115 120 M 80 110 L 60 160 L 55 210 M 80 110 L 100 160 L 105 210"
                    fill="none"
                    stroke={activeStep >= 1 ? "#3b82f6" : "#4b5563"}
                    strokeWidth="1"
                    className="transition-colors duration-500"
                  />

                  {/* Interactive Aura Nodes depending on Slider Index */}
                  {activeStep >= 1 && (
                    <g className="transition-all duration-500">
                      {/* Brain Cortex - active for Cortical node & up */}
                      <circle cx="80" cy="38" r="4" fill="#a855f7" className="animate-pulse" />
                      <line x1="80" y1="38" x2="120" y2="30" stroke="#a855f7" strokeWidth="0.75" />
                      <text x="124" y="33" fill="#a855f7" className="font-mono text-[8px] font-bold">NODE</text>
                    </g>
                  )}

                  {activeStep >= 2 && (
                    <g className="transition-all duration-500">
                      {/* Eye optic HUD - active for Lens & up */}
                      <circle cx="78" cy="42" r="2.5" fill="#10b981" />
                      <circle cx="82" cy="42" r="2.5" fill="#10b981" />
                      <line x1="82" y1="42" x2="132" y2="60" stroke="#10b981" strokeWidth="0.75" />
                      <text x="136" y="63" fill="#10b981" className="font-mono text-[8px] font-bold">HUD</text>
                    </g>
                  )}

                  {activeStep >= 3 && (
                    <g className="transition-all duration-500">
                      {/* Spine and limbs - active for Apex */}
                      <path d="M 80 60 L 80 105" stroke="#ec4899" strokeWidth="2.5" className="opacity-70 animate-pulse" />
                      {/* Left Bionic arm joints */}
                      <circle cx="50" cy="78" r="3.5" fill="#ec4899" />
                      <line x1="50" y1="78" x2="12" y2="90" stroke="#ec4899" strokeWidth="0.75" />
                      <text x="10" y="85" fill="#ec4899" className="font-mono text-[8px] font-bold">ARM</text>
                    </g>
                  )}
                </svg>
              </div>

              {/* Progress Display */}
              <div className="space-y-2">
                <div className="flex justify-between items-center text-[10px] font-mono text-zinc-400">
                  <span>AUGMENT DEPLOYMENT</span>
                  <span className="text-white font-bold">{step.enhancementLevel}%</span>
                </div>
                <div className="w-full h-1.5 bg-zinc-900 rounded-full overflow-hidden border border-zinc-800">
                  <motion.div
                    initial={{ width: "0%" }}
                    animate={{ width: `${step.enhancementLevel}%` }}
                    transition={{ type: "spring", stiffness: 80, damping: 15 }}
                    className="h-full bg-gradient-to-r from-cyan-500 via-indigo-500 to-purple-500 shadow-[0_0_8px_#3b82f6]"
                  />
                </div>
              </div>
            </div>
          </div>

          {/* Right Panel: Controls & Detailed Updates */}
          <div className="lg:col-span-7 flex flex-col justify-center">
            {/* Timeline phase quick selector */}
            <div className="flex flex-wrap gap-2.5 sm:gap-3.5 mb-10 w-full">
              {TIMELINE_STEPS.map((s, idx) => (
                <button
                  key={idx}
                  onClick={() => setActiveStep(idx)}
                  className={`px-4 py-2.5 rounded font-mono text-[10px] sm:text-xs font-semibold tracking-wider border transition-all duration-300 flex-1 min-w-[120px] text-center cursor-pointer ${
                    activeStep === idx
                      ? "bg-cyan-950/40 border-cyan-500/80 text-cyan-400 shadow-[0_0_15px_rgba(6,182,212,0.15)]"
                      : "bg-zinc-950/20 border-zinc-900 text-neutral-500 hover:border-zinc-700/60 hover:text-neutral-300"
                  }`}
                >
                  PHASE 0{idx + 1}
                </button>
              ))}
            </div>

            {/* Selected Phase details */}
            <AnimatePresence mode="wait">
              <motion.div
                key={activeStep}
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                transition={{ duration: 0.3 }}
                className="space-y-6"
              >
                <div className="space-y-2">
                  <div className="text-zinc-500 font-mono text-[11px] tracking-widest">{step.phase}</div>
                  <h3 className="text-2xl sm:text-3xl font-display font-medium text-white">{step.title}</h3>
                  <div className="text-cyan-500 font-mono text-xs">{step.year}</div>
                </div>

                <p className="text-neutral-400 text-sm sm:text-base leading-relaxed max-w-xl">
                  {step.description}
                </p>

                {/* Live Stats Cards aligned to active conversion step */}
                <div className="grid grid-cols-2 gap-4 sm:gap-6 pt-6">
                  {step.stats.map((stat) => (
                    <div
                      key={stat.label}
                      className="p-4 bg-zinc-950/40 border border-zinc-900 rounded flex flex-col transition-all duration-300 hover:border-cyan-500/30 group"
                    >
                      <span className="text-zinc-500 font-mono text-[10px] uppercase tracking-widest mb-1 group-hover:text-cyan-400 transition-colors">
                        {stat.label}
                      </span>
                      <span className="text-xl sm:text-2xl font-display font-bold text-white tracking-tight">
                        {stat.value}
                      </span>
                    </div>
                  ))}
                </div>
              </motion.div>
            </AnimatePresence>

            {/* Slider interface control */}
            <div className="mt-12 p-4 bg-zinc-950/40 border border-zinc-900/60 rounded-lg flex items-center gap-4 w-full">
              <Sliders className="w-5 h-5 text-cyan-400 flex-shrink-0" />
              <input
                type="range"
                min="0"
                max={TIMELINE_STEPS.length - 1}
                value={activeStep}
                onChange={(e) => setActiveStep(parseInt(e.target.value))}
                className="w-full accent-cyan-500 cursor-pointer bg-zinc-800 rounded-lg h-1"
                aria-label="Transformation Timeline Adjuster"
              />
              <span className="font-mono text-xs text-neutral-400 select-none">
                PH-0{activeStep + 1}
              </span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
