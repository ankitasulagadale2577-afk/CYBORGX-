import { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Zap, Sparkles, Key, Check } from "lucide-react";

export default function CTA() {
  const [subscribed, setSubscribed] = useState(false);
  const [syncStatus, setSyncStatus] = useState<"IDLE" | "SYNCING" | "COGNITIVE_ACTIVE">("IDLE");

  const startBionicSync = () => {
    setSyncStatus("SYNCING");
    setTimeout(() => {
      setSyncStatus("COGNITIVE_ACTIVE");
    }, 1800);
  };

  return (
    <section id="cta" className="py-24 sm:py-32 relative text-center overflow-hidden border-t border-zinc-950">
      {/* Immersive background ambient shadows */}
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(99,102,241,0.12)_0%,transparent_70%)] pointer-events-none" />

      {/* Decorative cyber grid scanning rings in background */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[520px] h-[520px] aspect-square rounded-full border border-dashed border-cyan-500/10 pointer-events-none animate-spin [animation-duration:90s]" />
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[340px] h-[340px] aspect-square rounded-full border border-dotted border-purple-500/10 pointer-events-none animate-spin [animation-duration:40s] [animation-direction:reverse]" />

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Large glassmorphic container panel */}
        <div className="relative py-16 px-6 sm:px-12 rounded-2xl bg-zinc-950/50 border border-cyan-500/20 backdrop-blur-3xl overflow-hidden shadow-[0_0_50px_rgba(6,182,212,0.06)]">
          
          {/* Neon laser scanlines */}
          <div className="absolute inset-x-0 top-0 h-0.5 bg-gradient-to-r from-transparent via-cyan-500/30 to-transparent animate-scanline" />

          {/* Icon indicator header */}
          <div className="mx-auto w-12 h-12 bg-neutral-900 border border-zinc-800 rounded-full flex items-center justify-center text-cyan-400 mb-6 drop-shadow-[0_0_8px_rgba(6,182,212,0.4)]">
            <Zap className="w-5 h-5 animate-pulse" />
          </div>

          <h2 className="text-4xl sm:text-6xl font-display font-black tracking-tight text-white mb-6 uppercase leading-none">
            JOIN THE <br />
            <span className="bg-gradient-to-r from-cyan-400 via-indigo-200 to-pink-500 bg-clip-text text-transparent drop-shadow-[0_0_10px_rgba(6,182,212,0.3)]">
              EVOLUTION
            </span>
          </h2>

          <p className="text-zinc-400 text-sm sm:text-base leading-relaxed max-w-xl mx-auto mb-10">
            Ditch your biochemical limits. Secure your cybernetic implant allocation queue and calibrate your cortex synapse gateway with the CYBORGX secure grid.
          </p>

          {/* Interactive Calibration Action Button */}
          <div className="flex flex-col items-center justify-center gap-4">
            <AnimatePresence mode="wait">
              {syncStatus === "IDLE" ? (
                <motion.button
                  key="idle"
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.95 }}
                  onClick={startBionicSync}
                  className="px-10 py-5 rounded bg-cyan-500 hover:bg-cyan-400 text-black font-display text-xs font-bold tracking-widest transition-all duration-300 hover:shadow-[0_0_30px_#06b6d4] uppercase cursor-pointer flex items-center gap-2.5 relative overflow-hidden group"
                >
                  <Sparkles className="w-4 h-4 animate-spin [animation-duration:3s]" />
                  Become Enhanced
                </motion.button>
              ) : syncStatus === "SYNCING" ? (
                <motion.div
                  key="syncing"
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.95 }}
                  className="px-10 py-5 rounded bg-zinc-900 border border-cyan-500/50 text-cyan-400 font-mono text-xs font-bold tracking-wider uppercase flex items-center gap-3"
                >
                  <svg className="animate-spin h-4 w-4 text-cyan-400" viewBox="0 0 24 24" fill="none">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                  </svg>
                  Syncing Synapses... Calibrating Telemetry
                </motion.div>
              ) : (
                <motion.div
                  key="active"
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  className="p-5 max-w-md bg-emerald-950/20 border border-emerald-500/30 rounded-lg flex flex-col items-center gap-2"
                >
                  <div className="w-8 h-8 rounded-full bg-emerald-500/10 flex items-center justify-center text-emerald-400 mb-1">
                    <Check className="w-5 h-5" />
                  </div>
                  <div className="font-mono text-xs font-bold text-white uppercase tracking-wider">
                    BIOLINK SYNAPSE ESTABLISHED [STABLE]
                  </div>
                  <p className="font-mono text-[10px] text-zinc-400 leading-relaxed text-center">
                    Cortex calibration matching telemetry synced at 99.98% efficiency. Check secure cyber communications network for direct lab scheduling coordinate keys. Welcome to Phase 04.
                  </p>
                </motion.div>
              )}
            </AnimatePresence>

            <span className="font-mono text-[9px] text-zinc-500 uppercase tracking-widest mt-4 flex items-center gap-1.5 select-none">
              <Key className="w-3.5 h-3.5 text-zinc-600" />
              SECURE BIOLINK KEY: SEC-G9-0112XX
            </span>
          </div>

        </div>

      </div>
    </section>
  );
}
