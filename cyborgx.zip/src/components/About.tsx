import { useEffect, useState } from "react";
import { motion, useMotionValue, useSpring } from "motion/react";
import { Award, FlaskConical, Users, Globe } from "lucide-react";

// Individual Animated Counter Item Component
function AnimatedCounter({ target, suffix = "", delay = 0 }: { target: number; suffix?: string; delay?: number }) {
  const [count, setCount] = useState(0);

  useEffect(() => {
    let start = 0;
    const end = target;
    if (start === end) return;

    // Set timeout delay matching the entrance animations
    const delayTimeout = setTimeout(() => {
      const duration = 2.0; // Seconds count progress runs
      const totalTicks = 60;
      const increment = end / totalTicks;
      const stepTime = (duration * 1000) / totalTicks;

      const timer = setInterval(() => {
        start += increment;
        if (start >= end) {
          setCount(end);
          clearInterval(timer);
        } else {
          setCount(Math.floor(start));
        }
      }, stepTime);

      return () => clearInterval(timer);
    }, delay * 1000);

    return () => clearTimeout(delayTimeout);
  }, [target, delay]);

  return (
    <span className="font-display text-2xl sm:text-4xl font-black text-white leading-none tracking-tight">
      {count.toLocaleString()}{suffix}
    </span>
  );
}

export default function About() {
  return (
    <section id="about" className="py-24 sm:py-32 relative overflow-hidden border-t border-zinc-950">
      {/* Visual glowing particle streams in background */}
      <div className="absolute top-1/2 right-10 w-72 h-72 bg-purple-500/5 rounded-full blur-[100px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 sm:gap-16 items-center">
          
          {/* Left panel: Futuristic Laboratory Image Showcase */}
          <motion.div
            initial={{ opacity: 0, x: -40 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, margin: "-100px" }}
            transition={{ duration: 0.7 }}
            className="lg:col-span-5 relative group"
          >
            {/* Ambient visual glowing frame borders */}
            <div className="absolute -inset-1.5 bg-gradient-to-r from-cyan-500/40 to-indigo-500/40 rounded-lg blur opacity-30 group-hover:opacity-60 transition duration-1000 animate-pulse-slow" />
            
            <div className="relative rounded-lg overflow-hidden bg-black border border-cyan-500/30">
              <img
                src="https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?auto=format&fit=crop&w=800&q=80"
                alt="CYBORGX Bionic Systems Engineering Laboratory"
                referrerPolicy="no-referrer"
                className="w-full object-cover aspect-[4/5] object-center scale-100 hover:scale-105 duration-700 brightness-[0.8]"
              />
              {/* Tech scanning overlays */}
              <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent opacity-90" />
              <div className="absolute inset-2 border border-cyan-500/10 pointer-events-none rounded" />
              
              {/* Corner target coordinates overlay */}
              <div className="absolute top-4 left-4 font-mono text-[9px] text-cyan-400 bg-black/75 px-2 py-1 rounded border border-cyan-500/20">
                LAB_LOC // TOKYO.SEC_9
              </div>
            </div>
          </motion.div>

          {/* Right panel: Manifesto, Stats, Metrics */}
          <motion.div
            initial={{ opacity: 0, x: 40 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, margin: "-100px" }}
            transition={{ duration: 0.7, delay: 0.1 }}
            className="lg:col-span-7 flex flex-col text-left"
          >
            <div className="inline-block px-3 py-1 bg-cyan-950/40 border border-cyan-500/30 rounded-full font-mono text-[10px] tracking-widest text-cyan-400 mb-4 uppercase w-fit">
              CORPORATE MANIFESTO
            </div>
            
            <h2 className="text-3xl sm:text-5xl font-display font-bold text-white tracking-tight leading-[1.1] mb-6 uppercase">
              SURPASSING THE{" "}
              <span className="bg-gradient-to-r from-indigo-300 via-purple-300 to-pink-400 bg-clip-text text-transparent">
                BIOLOGICAL BIAS.
              </span>
            </h2>

            <p className="text-zinc-400 text-sm sm:text-base leading-relaxed mb-6">
              Founded in 2023, CYBORGX began with a single mission: to free humanity from the shackles of
              biological decay. By integrating microscopic computing cells, robust titanium alloys, and secure neural encryption, we create the blueprint for human evolution.
            </p>
            <p className="text-zinc-400 text-sm sm:text-base leading-relaxed mb-10 border-l-2 border-cyan-500/30 pl-4 py-1 italic">
              "We dream of a civilization where biological boundaries are completely optional, and your intelligence scales at the rate of universal calculations."
            </p>

            {/* Simulated Animated Metrics */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 pt-6 border-t border-zinc-900 w-full">
              {/* Scientists */}
              <div className="flex gap-4 items-center">
                <div className="w-12 h-12 rounded bg-zinc-950 border border-zinc-900/80 flex items-center justify-center p-2 text-cyan-400">
                  <FlaskConical className="w-6 h-6" />
                </div>
                <div className="text-left">
                  <div className="flex items-center">
                    <AnimatedCounter target={100} suffix="+" delay={0.2} />
                  </div>
                  <div className="text-[10px] sm:text-xs font-mono text-zinc-500 uppercase tracking-wider mt-1">
                    Bio-Scientists
                  </div>
                </div>
              </div>

              {/* Countries */}
              <div className="flex gap-4 items-center">
                <div className="w-12 h-12 rounded bg-zinc-950 border border-zinc-900/80 flex items-center justify-center p-2 text-purple-400">
                  <Globe className="w-6 h-6" />
                </div>
                <div className="text-left">
                  <div className="flex items-center">
                    <AnimatedCounter target={50} suffix="+" delay={0.4} />
                  </div>
                  <div className="text-[10px] sm:text-xs font-mono text-zinc-500 uppercase tracking-wider mt-1">
                    Countries Core
                  </div>
                </div>
              </div>

              {/* Enhanced Users */}
              <div className="flex gap-4 items-center">
                <div className="w-12 h-12 rounded bg-zinc-950 border border-zinc-900/80 flex items-center justify-center p-2 text-pink-400">
                  <Users className="w-6 h-6" />
                </div>
                <div className="text-left">
                  <div className="flex items-center">
                    <AnimatedCounter target={1000000} suffix="+" delay={0.6} />
                  </div>
                  <div className="text-[10px] sm:text-xs font-mono text-zinc-500 uppercase tracking-wider mt-1">
                    Enhanced Users
                  </div>
                </div>
              </div>
            </div>

          </motion.div>
        </div>
      </div>
    </section>
  );
}
