import { useEffect, useState } from "react";
import { motion, useMotionValue, useSpring } from "motion/react";

export default function InteractiveCursor() {
  const [visible, setVisible] = useState(false);
  const [clicked, setClicked] = useState(false);
  const [hovered, setHovered] = useState(false);

  const cursorX = useMotionValue(-100);
  const cursorY = useMotionValue(-100);

  const springConfig = { damping: 25, stiffness: 250, mass: 0.5 };
  const springX = useSpring(cursorX, springConfig);
  const springY = useSpring(cursorY, springConfig);

  useEffect(() => {
    const moveCursor = (e: MouseEvent) => {
      cursorX.set(e.clientX);
      cursorY.set(e.clientY);
      if (!visible) setVisible(true);
    };

    const handleMouseLeave = () => setVisible(false);
    const handleMouseEnter = () => setVisible(true);

    const handleMouseDown = () => setClicked(true);
    const handleMouseUp = () => setClicked(false);

    // Look for hoverable elements (buttons, links, clickables)
    const handleMouseOver = (e: MouseEvent) => {
      const target = e.target as HTMLElement;
      if (
        target &&
        (target.tagName === "BUTTON" ||
          target.tagName === "A" ||
          target.closest("button") ||
          target.closest("a") ||
          target.classList.contains("clickable") ||
          target.getAttribute("role") === "button")
      ) {
        setHovered(true);
      } else {
        setHovered(false);
      }
    };

    window.addEventListener("mousemove", moveCursor);
    document.addEventListener("mouseleave", handleMouseLeave);
    document.addEventListener("mouseenter", handleMouseEnter);
    window.addEventListener("mousedown", handleMouseDown);
    window.addEventListener("mouseup", handleMouseUp);
    window.addEventListener("mouseover", handleMouseOver);

    return () => {
      window.removeEventListener("mousemove", moveCursor);
      document.removeEventListener("mouseleave", handleMouseLeave);
      document.removeEventListener("mouseenter", handleMouseEnter);
      window.removeEventListener("mousedown", handleMouseDown);
      window.removeEventListener("mouseup", handleMouseUp);
      window.removeEventListener("mouseover", handleMouseOver);
    };
  }, [cursorX, cursorY, visible]);

  if (!visible) return null;

  return (
    <>
      {/* Outer spinning targeting ring */}
      <motion.div
        id="cyber-cursor-ring"
        style={{
          x: springX,
          y: springY,
          translateX: "-50%",
          translateY: "-50%",
        }}
        animate={{
          scale: clicked ? 0.75 : hovered ? 1.5 : 1,
          borderColor: hovered ? "#ec4899" : "#06b6d4",
          rotate: hovered ? 180 : 0,
        }}
        transition={{ type: "spring", stiffness: 300, damping: 25 }}
        className="fixed top-0 left-0 w-8 h-8 rounded-full border-2 border-cyan-500 pointer-events-none z-50 flex items-center justify-center opacity-70 hidden md:flex"
      >
        {/* Decorative corner brackets */}
        {hovered && (
          <div className="absolute inset-0 border border-pink-500 rounded-full animate-ping opacity-40" />
        )}
      </motion.div>

      {/* Inner laser dot */}
      <motion.div
        id="cyber-cursor-dot"
        style={{
          x: cursorX,
          y: cursorY,
          translateX: "-50%",
          translateY: "-50%",
        }}
        animate={{
          scale: clicked ? 1.8 : hovered ? 0.4 : 1,
          backgroundColor: hovered ? "#ec4899" : "#a855f7",
          boxShadow: clicked
            ? "0 0 15px #ec4899, 0 0 30px #ec4899"
            : "0 0 8px #a855f7, 0 0 16px #a855f7",
        }}
        className="fixed top-0 left-0 w-2.5 h-2.5 rounded-full pointer-events-none z-50 hidden md:block"
      />
    </>
  );
}
