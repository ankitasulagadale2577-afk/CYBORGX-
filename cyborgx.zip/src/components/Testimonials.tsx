import { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Star, ChevronLeft, ChevronRight, Quote, MessageSquareQuote } from "lucide-react";
import { TestimonialItem } from "../types";

const TESTIMONIALS: TestimonialItem[] = [
  {
    id: "tester-1",
    name: "Sarah Vance",
    role: "Chief Tactics Officer // CorpSec",
    avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=150&h=150&q=80",
    content: "The Cyber Arm Pro has redefined field capabilities. Calibration required zero recovery time, and force regulation matches motor cortex intentions literally instantly. The titanium alloy weave feels completely natural.",
    rating: 5,
    enhancementType: "CYBER_ARM_PRO_v9",
  },
  {
    id: "tester-2",
    name: "Dr. Kaelen Park",
    role: "Quantum Software Architect // Syntheta",
    avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=150&h=150&q=80",
    content: "Integrating the Neural-X Implant felt like turning on an extra monitor in my brain. I can cross-evaluate complex encryption code pools and mathematical matrices directly in my sleep cycle. Exceptional integration stability.",
    rating: 5,
    enhancementType: "NEURAL_X_IMPLANT_CORE",
  },
  {
    id: "tester-3",
    name: "Miya Chen",
    role: "Aerospace Fleet Commander // AeroSpace-X",
    avatar: "https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=150&h=150&q=80",
    content: "Retinal HUD spectrum shifting on the Vision-X Lenses makes navigation in visual distortion atmospheres extremely trivial. Flying space-drones via direct ocular telemetry is a feeling I can no longer live without.",
    rating: 5,
    enhancementType: "VISION_X_HUD_LENS",
  },
];

export default function Testimonials() {
  const [index, setIndex] = useState(0);
  const [direction, setDirection] = useState(0); // -1 for left slide, 1 for right slide

  const handlePrev = () => {
    setDirection(-1);
    setIndex((prev) => (prev === 0 ? TESTIMONIALS.length - 1 : prev - 1));
  };

  const handleNext = () => {
    setDirection(1);
    setIndex((prev) => (prev === TESTIMONIALS.length - 1 ? 0 : prev + 1));
  };

  const current = TESTIMONIALS[index];

  // Sliding variations for transition effects
  const slideVariants = {
    enter: (direction: number) => ({
      x: direction > 0 ? 150 : -150,
      opacity: 0,
    }),
    center: {
      x: 0,
      opacity: 1,
    },
    exit: (direction: number) => ({
      x: direction < 0 ? 150 : -150,
      opacity: 0,
    }),
  };

  return (
    <section id="testimonials" className="py-24 sm:py-32 relative border-t border-zinc-950">
      {/* Glow Backdrops */}
      <div className="absolute top-1/4 right-[20%] w-72 h-72 bg-pink-500/5 rounded-full blur-[90px] pointer-events-none" />
      <div className="absolute bottom-1/4 left-[20%] w-72 h-72 bg-cyan-500/5 rounded-full blur-[90px] pointer-events-none" />

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 text-center">
        {/* Section Title */}
        <div className="max-w-3xl mx-auto mb-16 sm:mb-20">
          <div className="inline-block px-3 py-1 bg-purple-950/40 border border-purple-500/30 rounded-full font-mono text-[10px] tracking-widest text-purple-400 mb-4 uppercase">
            AUGMENTED COGNITIVE LOGS
          </div>
          <h2 className="text-3xl sm:text-5xl font-display font-bold tracking-tight text-white uppercase">
            TESTED BY THE <br />
            <span className="bg-gradient-to-r from-pink-400 to-amber-200 bg-clip-text text-transparent">
              ENHANCED ONIONS.
            </span>
          </h2>
        </div>

        {/* Testimonials Slider Frame */}
        <div className="relative bg-zinc-950/40 border border-zinc-900 rounded-xl p-8 sm:p-12 backdrop-blur-md overflow-hidden min-h-[380px] sm:min-h-[340px] flex flex-col justify-between">
          <Quote className="absolute top-6 left-6 text-zinc-900 w-24 h-24 stroke-[0.35] pointer-events-none" />

          {/* Sliding Content Container using AnimatePresence */}
          <div className="my-auto relative">
            <AnimatePresence custom={direction} mode="wait">
              <motion.div
                key={index}
                custom={direction}
                variants={slideVariants}
                initial="enter"
                animate="center"
                exit="exit"
                transition={{ duration: 0.35, ease: "easeInOut" }}
                className="space-y-6 sm:space-y-8"
              >
                {/* 5 Bionic rating stars */}
                <div className="flex justify-center gap-1">
                  {Array.from({ length: current.rating }).map((_, i) => (
                    <Star key={i} className="w-4 h-4 text-pink-500 fill-pink-500" />
                  ))}
                </div>

                {/* Testimonial Quote */}
                <p className="text-lg sm:text-2xl text-neutral-200 leading-relaxed max-w-2xl mx-auto font-normal font-sans tracking-wide">
                  "{current.content}"
                </p>

                {/* Profile Bio */}
                <div className="flex flex-col sm:flex-row items-center justify-center gap-4 pt-4 border-t border-zinc-900/60 max-w-sm mx-auto">
                  <div className="relative w-12 h-12 flex-shrink-0">
                    <img
                      src={current.avatar}
                      alt={current.name}
                      referrerPolicy="no-referrer"
                      className="w-full h-full rounded-full object-cover border border-cyan-500/50"
                    />
                    <span className="absolute -bottom-0.5 -right-0.5 w-3 h-3 bg-cyan-400 border border-black rounded-full animate-pulse" />
                  </div>
                  <div className="text-center sm:text-left font-mono">
                    <div className="text-sm text-white font-bold">{current.name}</div>
                    <div className="text-[10px] text-zinc-500 mt-0.5">{current.role}</div>
                    <span className="inline-block mt-1 text-[9px] bg-cyan-950/40 text-cyan-400 border border-cyan-500/20 px-1.5 py-0.5 rounded leading-none font-bold">
                      {current.enhancementType}
                    </span>
                  </div>
                </div>
              </motion.div>
            </AnimatePresence>
          </div>

          {/* Interactive Navigation controls */}
          <div className="flex justify-between items-center mt-10 pt-4 border-t border-zinc-900/40">
            {/* Sliding navigation dots */}
            <div className="flex gap-2">
              {TESTIMONIALS.map((_, i) => (
                <button
                  key={i}
                  onClick={() => {
                    setDirection(i > index ? 1 : -1);
                    setIndex(i);
                  }}
                  className={`w-2.5 h-1.5 rounded-full transition-all duration-300 ${
                    index === i ? "bg-cyan-400 w-6" : "bg-zinc-800 hover:bg-zinc-750"
                  }`}
                  aria-label={`Go to Testimonial ${i + 1}`}
                />
              ))}
            </div>

            {/* Slider navigation Arrow buttons */}
            <div className="flex gap-2.5 sm:gap-4 select-none">
              <button
                onClick={handlePrev}
                className="w-10 h-10 border border-zinc-900 hover:border-cyan-500/40 rounded bg-zinc-950/60 hover:bg-zinc-900 text-cyan-400 hover:shadow-[0_0_10px_rgba(6,182,212,0.15)] transition-all duration-300 flex items-center justify-center cursor-pointer"
                aria-label="Previous Testimonial"
              >
                <ChevronLeft className="w-5 h-5" />
              </button>
              <button
                onClick={handleNext}
                className="w-10 h-10 border border-zinc-900 hover:border-cyan-500/40 rounded bg-zinc-950/60 hover:bg-zinc-900 text-cyan-400 hover:shadow-[0_0_10px_rgba(6,182,212,0.15)] transition-all duration-300 flex items-center justify-center cursor-pointer"
                aria-label="Next Testimonial"
              >
                <ChevronRight className="w-5 h-5" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
