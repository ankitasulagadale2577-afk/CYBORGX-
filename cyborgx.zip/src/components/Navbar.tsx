import { useState, useEffect, MouseEvent } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Menu, X, Cpu, ShieldAlert } from "lucide-react";

export default function Navbar() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 20) {
        setIsScrolled(true);
      } else {
        setIsScrolled(false);
      }
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const navItems = [
    { name: "Home", href: "#hero" },
    { name: "Technology", href: "#technology" },
    { name: "Features", href: "#features" },
    { name: "Products", href: "#products" },
    { name: "About", href: "#about" },
    { name: "Contact", href: "#footer" },
  ];

  const handleScrollToSegment = (e: MouseEvent<HTMLAnchorElement>, href: string) => {
    e.preventDefault();
    setMobileMenuOpen(false);
    const element = document.querySelector(href);
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <>
      <header
        className={`fixed top-0 left-0 w-full z-45 transition-all duration-300 ${
          isScrolled
            ? "bg-black/75 border-b border-cyan-500/20 py-3 backdrop-blur-xl shadow-[0_10px_30px_rgb(0,0,0,0.8)]"
            : "bg-transparent border-b border-transparent py-5"
        }`}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex justify-between items-center">
          {/* Logo */}
          <motion.a
            href="#hero"
            onClick={(e) => handleScrollToSegment(e, "#hero")}
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            className="flex items-center gap-2 font-display text-white tracking-widest font-black text-xl select-none group"
          >
            <div className="relative w-9 h-9 flex items-center justify-center p-1 rounded-lg bg-cyan-950/40 border border-cyan-500/30 group-hover:border-cyan-400 group-hover:shadow-[0_0_15px_rgba(6,182,212,0.5)] transition-all">
              <Cpu className="w-5 h-5 text-cyan-400 group-hover:rotate-45 transition-transform duration-300" />
              <div className="absolute inset-0 bg-cyan-400/10 rounded-lg scale-0 group-hover:scale-100 transition-transform duration-300" />
            </div>
            <span className="bg-gradient-to-r from-white via-cyan-200 to-cyan-400 bg-clip-text text-transparent">
              CYBORG<span className="text-cyan-400 font-bold glow-cyan">X</span>
            </span>
          </motion.a>

          {/* Nav Items (Desktop) */}
          <nav className="hidden lg:flex items-center gap-8">
            {navItems.map((item, index) => (
              <motion.a
                key={item.name}
                href={item.href}
                onClick={(e) => handleScrollToSegment(e, item.href)}
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.05 }}
                className="font-mono text-xs tracking-wider text-neutral-400 hover:text-white uppercase transition-colors relative py-1 group"
              >
                {item.name}
                <span className="absolute bottom-0 left-0 w-0 h-[2px] bg-gradient-to-r from-cyan-500 to-indigo-500 group-hover:w-full transition-all duration-300" />
              </motion.a>
            ))}
          </nav>

          {/* CTA Action Header */}
          <div className="hidden lg:block">
            <motion.a
              href="#cta"
              onClick={(e) => handleScrollToSegment(e, "#cta")}
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              whileHover={{ scale: 1.05 }}
              className="px-5 py-2 rounded font-display text-[11px] font-bold tracking-widest bg-gradient-to-r from-cyan-500 to-indigo-500 text-black hover:shadow-[0_0_20px_rgba(6,182,212,0.6)] duration-300 flex items-center gap-1.5 border border-cyan-400/40 relative overflow-hidden"
            >
              <span className="absolute inset-x-0 h-[100%] w-3 bg-white/20 -skew-x-12 translate-x-[-100%] hover:animate-pulse group-hover:translate-x-[400%] transition-transform duration-1000" />
              BIOLINK SECURE
            </motion.a>
          </div>

          {/* Hamburger (Mobile) */}
          <div className="lg:hidden flex items-center">
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="text-neutral-400 hover:text-cyan-400 p-2 focus:outline-none transition-colors"
              aria-label="Toggle Menu"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </header>

      {/* Drawer Menu (Mobile) */}
      <AnimatePresence>
        {mobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.2 }}
            className="fixed inset-x-0 top-18 bg-black/95 border-b border-cyan-950/80 p-6 z-40 backdrop-blur-3xl lg:hidden max-h-[85vh] overflow-y-auto"
          >
            <div className="flex flex-col gap-5">
              {navItems.map((item) => (
                <a
                  key={item.name}
                  href={item.href}
                  onClick={(e) => handleScrollToSegment(e, item.href)}
                  className="font-display font-medium text-lg tracking-wider text-neutral-300 hover:text-cyan-400 py-2 border-b border-neutral-900 duration-200 block uppercase"
                >
                  {item.name}
                </a>
              ))}
              <div className="mt-4 pt-4 border-t border-cyan-950/60">
                <a
                  href="#cta"
                  onClick={(e) => handleScrollToSegment(e, "#cta")}
                  className="w-full text-center block px-6 py-3.5 rounded font-display text-[12px] font-bold tracking-widest bg-gradient-to-r from-cyan-500 to-indigo-500 text-black shadow-[0_0_15px_rgba(6,182,212,0.4)]"
                >
                  BIOLINK SECURE
                </a>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
