export interface FeatureUnit {
  id: string;
  title: string;
  description: string;
  iconName: string;
  glowColor: string; // Tailwind class e.g., 'group-hover:shadow-[0_0_25px_rgba(59,130,246,0.5)]'
  borderColor: string;
  badge: string;
}

export interface TechnologyStep {
  phase: string;
  title: string;
  year: string;
  description: string;
  stats: { label: string; value: string }[];
  enhancementLevel: number; // 0 to 100
}

export interface ProductItem {
  id: string;
  name: string;
  tagline: string;
  price: string;
  description: string;
  features: string[];
  imageUrl: string;
  specs: { label: string; value: string }[];
}

export interface TestimonialItem {
  id: string;
  name: string;
  role: string;
  avatar: string;
  content: string;
  rating: number;
  enhancementType: string;
}
