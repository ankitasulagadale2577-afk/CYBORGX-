/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect } from "react";
import LoadingScreen from "./components/LoadingScreen";
import ParticleBackground from "./components/ParticleBackground";
import InteractiveCursor from "./components/InteractiveCursor";
import Navbar from "./components/Navbar";
import Hero from "./components/Hero";
import Features from "./components/Features";
import Showcase from "./components/Showcase";
import Products from "./components/Products";
import About from "./components/About";
import Testimonials from "./components/Testimonials";
import CTA from "./components/CTA";
import Footer from "./components/Footer";

export default function App() {
  const [loading, setLoading] = useState(true);

  // Lock scroll when systems are booting up
  useEffect(() => {
    if (loading) {
      document.body.style.overflow = "hidden";
    } else {
      document.body.style.overflow = "unset";
    }
    return () => {
      document.body.style.overflow = "unset";
    };
  }, [loading]);

  return (
    <div id="cyborgx-application-host" className="relative min-h-screen">
      {/* Immersive Particle Canvas Backplane */}
      <ParticleBackground />

      {/* Futuristic interactive targeting scope cursor */}
      <InteractiveCursor />

      {/* Loading screening sequence */}
      <LoadingScreen onComplete={() => setLoading(false)} />

      {/* Main layout contents (revealed after bootload sequence completes) */}
      {!loading && (
        <div className="relative z-10 transition-opacity duration-1000 opacity-100">
          {/* Transparent Glass Sticky Navbar */}
          <Navbar />

          <main>
            {/* Interactive Hero HUD Arena */}
            <Hero />

            {/* Bionic 3D Feature Grid */}
            <Features />

            {/* Transformation Timeline Slider */}
            <Showcase />

            {/* Hardware spec sheets list */}
            <Products />

            {/* Research Lab & Manifesto metrics */}
            <About />

            {/* tester logs carousel slider */}
            <Testimonials />

            {/* become enhanced call-to-action */}
            <CTA />
          </main>

          {/* Footnotes links navigation feeds */}
          <Footer />
        </div>
      )}
    </div>
  );
}
